//
//  ___FILEHEADER___
//

import APLayoutKit

final class ___FILEBASENAME___: APBaseView {
    override func setup() {

    }
}

#if targetEnvironment(simulator)
import SwiftUI

@available (iOS 13.0, *)
struct ___FILEBASENAME____Previews: PreviewProvider {
    static var previews: some View {
        Group {
            Preview {
                ___FILEBASENAME___()
            }
        }
    }
}
#endif
